"""Classes of random variables."""

from collections.abc import Callable
from pathlib import Path

import numpy as np
from numpy import sqrt

from dapper.tools.matrices import CovMat
from dapper.tools.repr_util import YamlRepr
from dapper.tools.seeding import rng


class RV(YamlRepr):
    """Class to represent random variables."""

    def __init__(
        self,
        M: int,
        *,
        is0: bool = False,
        func: Callable | None = None,
        file: str | Path | None = None,
        icdf: Callable | None = None,
        cdf: Callable | None = None,
    ):
        """Init arguments:

        - `M    <int>    ` : ndim
        - `is0  <bool>   ` : if `True`, the random variable is identically 0
        - `func <func(N)>` : use this sampling function. Example:
                           `RV(M=4,func=lambda N: rng.random((N,4))`
        - `file <str>    ` : draw from file. Example:
                           `RV(M=4,file=dpr.rc.dirs.data/'tmp.npz')`
        - `icdf <func(x)>` : marginal/independent "inverse transform" sampling.
                           Example: `RV(M=4,icdf=scipy.stats.norm.ppf)`
        - `cdf <func(x)>`  : as icdf, but with approximate icdf from interpolation.
                           Example: `RV(M=4,cdf=scipy.stats.norm.cdf)`
        """
        self.M = M
        self.is0 = is0
        self.func = func
        self.file = file
        self.icdf = icdf
        self.cdf = cdf
        self._icdf_interp = None

    def sample(self, N: int) -> np.ndarray:
        if self.is0:
            # Identically 0
            E = np.zeros((N, self.M))
        elif self.func is not None:
            # Provided by function
            E = self.func(N)
        elif self.file is not None:
            # Provided by numpy file with sample
            data = np.load(self.file)
            sample = data["sample"]
            N0 = len(sample)
            if "w" in data:
                w = data["w"]
            else:
                w = np.ones(N0) / N0
            idx = rng.choice(N0, N, replace=True, p=w)
            E = sample[idx]
        elif self.icdf is not None:
            # Independent "inverse transform" sampling
            icdf = np.vectorize(self.icdf)
            uu = rng.random((N, self.M))
            E = icdf(uu)
        elif self.cdf is not None:
            # Like above, but with inv-cdf approximate, from interpolation
            if self._icdf_interp is None:
                # Define inverse-cdf
                from scipy.interpolate import interp1d
                from scipy.optimize import fsolve

                cdf = self.cdf
                Left = fsolve(lambda x: cdf(x) - 1e-9, 0.1)[0]
                Right = fsolve(lambda x: cdf(x) - (1 - 1e-9), 0.1)[0]
                xx = np.linspace(Left, Right, 1001)
                uu = np.vectorize(cdf)(xx)
                icdf = interp1d(uu, xx)
                self._icdf_interp = np.vectorize(icdf)
            uu = rng.random((N, self.M))
            E = self._icdf_interp(uu)
        else:
            raise KeyError
        if self.M != E.shape[1]:
            raise ValueError(
                f"sample shape mismatch: expected M={self.M},"
                " got E.shape[1]={E.shape[1]}"
            )
        return E


# TODO 4: improve constructor (treatment of arg cases is too fragile).
class RV_with_mean_and_cov(RV):
    """Generic multivariate random variable characterized by mean and cov.

    This class must be subclassed to provide sample(),
    i.e. its main purpose is provide a common convenience constructor.
    """

    def __init__(
        self,
        mu: float | np.ndarray = 0,
        C: float | np.ndarray | CovMat = 0,
        M: int | None = None,
    ):
        """Init allowing for shortcut notation."""
        if isinstance(mu, CovMat):
            raise TypeError(
                "Got a covariance paramter as mu. " + "Use kword syntax (C=...) ?"
            )

        # Set mu
        mu = np.atleast_1d(mu)
        assert mu.ndim == 1
        if len(mu) > 1:
            if M is None:
                M = len(mu)
            else:
                assert len(mu) == M
        else:
            if M is not None:
                mu = np.ones(M) * mu

        # Set C
        if isinstance(C, CovMat):
            if M is None:
                M = C.M
        else:
            if np.isscalar(C) and C == 0:
                pass  # Assign as pure 0!
            else:
                if np.isscalar(C):
                    M = len(mu)
                    assert isinstance(C, (int, float))
                    C = CovMat(C * np.ones(M), "diag")
                else:
                    C = CovMat(C)
                    if M is None:
                        M = C.M

        # Validation
        if len(mu) not in (1, M):
            raise TypeError("Inconsistent shapes of (M,mu,C)")
        if M is None:
            raise TypeError("Could not deduce the value of M")
        if isinstance(C, CovMat) and M != C.M:
            raise TypeError("Inconsistent shapes of (M,mu,C)")

        # Assign
        self.M = M
        self.mu = mu
        self.C = C

    def sample(self, N: int) -> np.ndarray:
        """Sample N realizations. Returns N-by-M (ndim) sample matrix.

        Examples
        --------
        >>> plt.scatter(*(UniRV(C=randcov(2)).sample(10**4).T))  # doctest: +SKIP
        """
        if self.C == 0:
            D = np.zeros((N, self.M))
        else:
            assert isinstance(self.C, CovMat)
            D = self._sample(N, self.C)
        return self.mu + D

    def _sample(self, N: int, C: CovMat) -> np.ndarray:
        raise NotImplementedError("Must be implemented in subclass")


class GaussRV(RV_with_mean_and_cov):
    """Gaussian (Normal) multivariate random variable."""

    def _sample(self, N, C):
        R = C.Right
        D = rng.standard_normal((N, len(R))) @ R
        return D


class LaplaceRV(RV_with_mean_and_cov):
    """Laplace (double exponential) multivariate random variable.

    This is an elliptical generalization. Ref:
    Eltoft (2006) "On the Multivariate Laplace Distribution".
    """

    def _sample(self, N, C):
        R = C.Right
        z = rng.exponential(1, N)
        D = rng.standard_normal((N, len(R)))
        D = z[:, None] * D
        return D @ R / sqrt(2)


class LaplaceParallelRV(RV_with_mean_and_cov):
    """A NON-elliptical multivariate version of Laplace (double exponential) RV."""

    def _sample(self, N, C):
        # R = C.Right   # contour: sheared rectangle
        R = C.sym_sqrt  # contour: rotated rectangle
        D = rng.laplace(0, 1, (N, len(R)))
        return D @ R / sqrt(2)


class StudRV(RV_with_mean_and_cov):
    """Student-t multivariate random variable.

    Assumes the covariance exists,
    which requires `degreee-of-freedom (dof) > 1+ndim`.
    Also requires that dof be integer,
    since chi2 is sampled via Gaussians.
    """

    def __init__(self, dof, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.dof = dof

    def _sample(self, N, C):
        R = C.Right
        nu = self.dof
        r = nu / np.sum(rng.standard_normal((N, nu)) ** 2, axis=1)  # InvChi2
        D = sqrt(r)[:, None] * rng.standard_normal((N, len(R)))
        return D @ R * sqrt((nu - 2) / nu)


class UniRV(RV_with_mean_and_cov):
    """Uniform multivariate random variable.

    Has an elliptic-shape support.
    Ref: Voelker et al. (2017) "Efficiently sampling
    vectors and coordinates from the n-sphere and n-ball"
    """

    def _sample(self, N, C):
        R = C.Right
        D = rng.standard_normal((N, len(R)))
        r = rng.random(N) ** (1 / len(R)) / np.sqrt(np.sum(D**2, axis=1))
        D = r[:, None] * D
        return D @ R * 2


class UniParallelRV(RV_with_mean_and_cov):
    """Uniform multivariate random variable.

    Has a parallelogram-shaped support, as determined by the cholesky factor
    applied to the (corners of) the hypercube.
    """

    def _sample(self, N, C):
        R = C.Right
        D = rng.random((N, len(R))) - 0.5
        return D @ R * sqrt(12)
